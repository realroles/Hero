# RealRoles Backend

## Features
- Upload a video and translate the speech into another language
- Uses OpenAI Whisper for transcription
- Uses GPT for translation
- Uses Google TTS for dubbing
- Merges audio & video using ffmpeg

## Setup

1. Clone this repo:
```bash
git clone https://github.com/realroles/Real.git
```

2. Install dependencies:
```bash
npm install
```

3. Create `.env` file from `.env.example` and add your API keys.

4. Run server:
```bash
node index.js
```

## Requirements
- Node.js
- ffmpeg installed
- Google Cloud TTS credentials JSON
